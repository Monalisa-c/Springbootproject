package com.springbootjwt.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int aId;
	
	@Column(length=30)
	private String building;
	
	@Column(length=30)
	private String city;
	
	@Column(length=30)
	private String state;
	
	@Column(length=6)
	private int pincode;
}
